# dirtycow 

[![Build Status](https://travis-ci.org/xlucas/dirtycow.cr.svg?branch=master)](https://travis-ci.org/xlucas/dirtycow.cr)
[![Github All Releases](https://img.shields.io/github/downloads/xlucas/dirtycow.cr/total.svg)](https://github.com/xlucas/dirtycow.cr/releases)

CVE-2016-5195 exploit


## Installation

Go to the [release section](https://github.com/xlucas/dirtycow.cr/releases) or use your crystal environment.

## Usage

```bash
dirtycow --target /path/to/root/file --string "string to write" --offset <offset_in_file>
```
